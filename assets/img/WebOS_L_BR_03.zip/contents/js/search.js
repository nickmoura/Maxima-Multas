var searchFocus;
$(function(){
	/*
	$("#popup_searchs li:eq(0)").addClass("select").css({"background-color":"#da1961"});
	$("#popup_searchs li:eq(0)").children().css({"color":"#fff", "background-position-y":"-76px"});
	

	$("body").on("keydown","#popup_searchs li",function(e){
		if(e.keyCode == "38"){
			if($(this).index() == 0){
				parent.$(".scloseBtn").focus();
				parent.$(".scloseBtn img").attr("src","img/common/btn_close_over.png");
			};
			$(this).prev().children("a").focus();
			$(this).removeClass("select").css({"background-color":"#686868"});
			$(this).children().css({"color":"#fff", "background-position-y":"0px"});

			$(this).prev().addClass("select").css({"background-color":"#da1961"});
			$(this).prev().children().css({"color":"#fff", "background-position-y":"-76px"});
		}else if(e.keyCode == "40"){
			var iframeListCount = $(this).parent().children().length;
			
			if($(this).last().index() == iframeListCount-1){ //하위메뉴가 없을때 이동하지 못하게...
				return;
			}

			$(this).next().children("a").focus();
			
			$(this).removeClass("select").css({"background-color":"#686868"});
			$(this).children().css({"color":"#fff", "background-position-y":"0px"});

			$(this).next().addClass("select").css({"background-color":"#da1961"});
			$(this).next().children().css({"color":"#fff", "background-position-y":"-76px"});
		}
	});

	
	
	$("body").on("click","#popup_searchs li a",function(){
		
		var tempPath = $(this).attr("navi");
		parent.searchInputCheck = true;
		path = tempPath.split(">");
		$("#oneDepth_navi",parent.document).text(path[0]);
		$("#twoDepth_navi",parent.document).text(path[1]);
		$("#thrDepth_navi",parent.document).hide();
		if(path[2]){
			$("#thrDepth_navi",parent.document).text(path[2]);
			$("#thrDepth_navi",parent.document).show();
		}
		var searchURL = $(this).attr("href");
		parent.searchIndex = $(this).parent().index();
		
		$(".popup",parent.document).show();
		$(".modal_bg",parent.document).show();
		$("#popupIframe",parent.document).attr("src",searchURL);
		setTimeout(setPopupIframe,500);
		return false;
	});	
	*/

});

function init(){
	$("li")	.css({"background-color":"#686868"});
	$(".title1").css({"color":"#fff"});
	$(".title2").css({"color":"#c8c8c8", "background-position-y":"-16px"})
}


function setPopupIframe(){
		//parent.$("#popupIframe").contents().find("body").focus();
		$("#popupIframe",parent.document).contents().find("body").focus();
}
