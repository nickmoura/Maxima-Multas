window.searchFocus;
var depth1_select;     //one Depth가 선택되었을때 객체를 담는 변수
var depth2_select;     //two Depth가 선택되었을때 객체를 담는 변수
var depth3_select;     //two Depth가 선택되었을때 객체를 담는 변수
var seleted;
var selectedOneDepth;  //선택된 one Depth 인덱스
var currentFocus;      //현재 선택된 포커스 
var depth2_prevSelect;
window.searchInputCheck = false;
var oneDepthOverObj;
var searchIndex;
var focusOutObj;
window.onload = function () {
	ChangeMaxLength();
}


//////////////////////////////////// start $(function(){}) //////////////////////////
$(function(){
	
	$(".modal_bg").hide();
	$(".modal_search_bg").hide();
	$(".menu_list li:eq(0) a").focus();
	//$("#searcheText").focus();
	selectedOneDepth = 1;
	currentFocus = $(".menu_list li:eq(0) a");
	
	depth1_select=$(".bg1").get(0);
	$(".bg1").addClass("select").css("background-position-y","-90px").css("background-color","#fff");
	$(".bg1 .title").css({"background-position-y":"-44px", "color":"#cf0652"});
	
	depth_two();
	popupClose();
	
	$("ul:not(:first)").hide();
	$(".contents_list").hide();
	$("#twoDepth1").show();
	$(".slide").hide();
	
	
	$(".btn_back").hover(function(){
		$(this).children("img").attr("src","img/common/btn_back_over.png");
	},function(){
		$(this).children("img").attr("src","img/common/btn_back.png");
	});
	
	$(".btn_bye").hover(function(){
		$(this).children("img").attr("src","img/common/btn_bye_over.png");
	},function(){
		$(this).children("img").attr("src","img/common/btn_bye.png");
	});
	
	
	$(".scloseBtn").hover(function(){
		$(".scloseBtn img").attr("src","img/common/btn_close_over.png");
		},
		function(){
		$(".scloseBtn img").attr("src","img/common/btn_close.png");
	});

	$(".closeBtn").hover(function(){
		$(".closeBtn img").attr("src","img/common/btn_close_over.png");
		},
		function(){
		$(".closeBtn img").attr("src","img/common/btn_close.png");
	});
	

//////////////////////// search  ////////////////////////////////////
	
	$("#searcheText").css("color","#aaa").one("focus",function(){
		$(this).val("");
		$(".form").css({"background-position-y":"-79px"});
		/*$(".modal_input_bg").show();*/
		$(".searchInputTxt").hide();
	}).blur(function(){
		//버추얼 키보드에서 enter를 눌렀을때..
		if($(this).val() == ""){
			$(".form").css({"background-position-y":"0px"});
			//$(".searchInputTxt").show();
			$(this).one("focus",function(){
				/*$(".modal_input_bg").show();*/
				$(this).css("color","#333");
				$(".form").css({"background-position-y":"-79px"});
			});
			
			//$(this).css("z-index","5");
			
		}
	});
	
	$("#searcheText").click(function(){
		$(".form").css({"background-position-y":"-79px"});
		$(".searchInputTxt").hide();
		$(".searchInputTxt").css("z-index","4")
	});
	
	$(".form").hover(
		function(){
			$(this).css({"background-position-y":"-39px"});
			//$(".searchInputTxt").hide();
			//$(".searchInputTxt").css("z-index","4")
		},
		function(){
			$(this).css({"background-position-y":"0px"});
			//$(".searchInputTxt").show();
			//$(".searchInputTxt").css("z-index","6")
	});

/*--------------------- one Depth 메뉴, 포커스, 오버시 ---------------------------*/
	$(".menu_list li a").focus(function(){
		//$(".tutorial").hide();	
		//$(".contents_box").show();
		depth_one();
		menuInit();
		twoDepthInit();
		selected=$(this);
		depth1_select=$(this).get(0);
		selectedOneDepth =$(this).parent("li").index(); 
		
		var divName = $(this).attr("href");
		$(divName).show();
		oneDepthFocus($(this));
		$(".searchInputTxt").show();
		return false;
	}).click(function(){
		$(".tutorial").hide();
		$(".contents_box").show();
		depth_one();
		menuInit();
		twoDepthInit();
		$(this).focus();
		depth1_select=$(this).get(0);
		currentFocus = $(this).focus();
		selected=$(this);
		selectedOneDepth =$(this).parent("li").index(); 
		$(this).addClass("over");
		var divName = $(this).attr("href");
		$(divName).show();
		twoDepthOutFunc($(".contents_list dt"));
		return false;
	});
	
	// one Depth 오버시 
	$(".menu_list li a").hover(function(){
		//VKHideFocus();
		$(".searchInputTxt").show();
		oneDepthOverObj = $(this);
		$(this).focus();
		depth1_select=$(this).get(0);
		twoDepthOutFunc($(".contents_list dt"));//twoDepth  선택내용이 빠짐..
		oneDepthOver1($(this));
	},function(){
		//oneDepthOut1($(this));
	});
	
	function oneDepthFocus(obj){
		obj.addClass("select").css("background-position-y","-90px").css("background-color","#fff");
		obj.children().css({"background-position-y":"-44px", "color":"#cf0652"});
	}
	
	function oneDepthOver(obj){
		obj.css({"background-position-y":"-45px","background-color":"#cf0652"});
		obj.children().css({"background-position-y":"-45px", "color":"#fff"});
	}
	
	function oneDepthOver1(obj){
		obj.css({"background-position-y":"-90px", "color":"#cf0652"});
		obj.children().css({"background-position-y":"-45px", "color":"#cf0652"});
	}
	
	function oneDepthOut(obj){
		obj.css({"background-position-y":"0px","background-color":"#ededed"});
		obj.children().css({"background-position-y":"0px", "color":"#717171"});
	}
	
	function oneDepthOut1(obj){
		obj.children().css("color","#cf0652");
	}
	
	function hoverObj(obj){
		//obj.parent().css("background-color","#efefef");
		obj.css({"background-position-y":"0px","background-color":"#ededed"});
		obj.children().css({"background-position-y":"0px", "color":"#717171"});
	}
/*-------------------- two Depth가 포커스를 얻었을때, 오버시 ------------------------*/

	$(".contents_list dt a").click(function(){
		depth_two();
		$(this).focus();
		twoDepthClearFunc();
		currentFocus = $(this).focus();
		if($(this).children().attr("class") == "plus"){
			twoDepthClickFunc($(this));
		}else{
			//twoDepthClickFunc($(this));
		}
		
		if($(this).parent().next(".slide").html() == undefined){ // three Depth가 없을때..
			$(this).addClass("open");
			$(".popup").show();
			$(".modal_bg").show();
			var tempPath = $(this).attr("path");
			path = tempPath.split("@@@");
			$("#oneDepth_navi").html(path[0]);
			$("#twoDepth_navi").html(path[1]);
			$("#thrDepth_navi").hide();
			var linkURL = $(this).attr("href");  // 링크에 href 속성 가져옴 소스코드 보면 li에 href 이름넣은거 확인!
			$("#popupIframe").attr("src", linkURL);
			window.popupCheck = true;
			$(".iframediv").scrollTop(0);
			setPopupFocusList();
		}else{ // three Depth가 있을때...
			
			if($(this).parent().next("ol.slide").css("display") == "none"){
				$(this).parent().next("ol.slide").slideDown();	
			}else{
				$(this).parent().next("ol.slide").slideUp();
			}	
		}
		depth2_select=$(this).get(0);
		twoDepthClickFunc($(this).parent());
		return false;
	});

	
	$(".contents_list dt a").hover(function(){
		twoDepthClearFunc();
		//VKHideFocus();
		currentFocus = $(this).focus();
		//twoDepthOutFunc(currentFocus.parent());
		twoDepthOverFunc($(this).parent());
		$(".searchInputTxt").show();
		
	},function(){
		/*
		if(depth2_select != $(this).get(0)){
			twoDepthOutFunc($(this).parent());
		}else{
			twoDepthClickFunc($(this));
		}
		depth2_prevSelect = $(this).parent();
		*/
		twoDepthOverFunc($(this).parent());
	});


	
/*--------------------------- three Depth 클릭했을때  -------------------------*/
	$(".slide li a").click(function(){
		$(".popup").show();
		$(".modal_bg").show();
		var tempPath = $(this).attr("path");
		path = tempPath.split("@@@");
		$("#oneDepth_navi").html(path[0]);
		$("#twoDepth_navi").html(path[1]);
		$("#thrDepth_navi").hide();
		if(path[2]){
			$("#thrDepth_navi").show();
			$("#thrDepth_navi").html(path[2]);
		}
		
		$(this).focus();
		currentFocus = $(this).focus();
		//threeDepthSelectFunc($(this).parent());
		var hrefattr=$(this).attr("href");  // 링크에 href 속성 가져옴 소스코드 보면 li에 href 이름넣은거 확인!
		$("#popupIframe").attr("src",hrefattr);
		setPopupFocusList();
		depth3_select = $(this).get(0);
		return false;
	}).hover(function(){
		
		threeDepthOutFunc(currentFocus.parent());
		//twoDepthOutFunc(currentFocus.parent());
		twoDepthClickFunc($(this).parent().parent().prev().children());
		threeDepthOverFunc($(this).parent());	
		
		
	},function(){
		//if(depth3_select != $(this).get(0)){
			threeDepthOutFunc($(this).parent());	
		//}
		
	});	

/*--------------------------- 팝업창 닫기를 클릭했을때  --------------------------*/
	$(".closeBtn").click(function(){  
		$("#popupIframe").attr("src","popup.html");
		$(".popup").hide();
		$(".modal_bg").hide();
		$(".closeBtn img").attr("src","img/common/btn_close.png");
		if(window.searchInputCheck){
			//포커스 위치를 검색위치로...
			console.log("========= close btn");
			window.selectedSearchList.focus();
			window.searchInputCheck = false;
		}else{
			popupClose();	
		}
		window.popupCheck = false;
		return false;
	});

	
/*--------------------------- 검색닫기를 클릭했을때  -----------------------------*/	

	$(".scloseBtn").click(function(){
		popupClose();
		$("#searcheText").removeAttr("readonly");
		$(".popup_search").hide();
		$(".modal_search_bg").hide();
		$(".modal_input_bg").hide();
		$("#clickBtn").focus();
		$(".searchInputTxt").show();
		$("#clickBtn img").attr("src","./img/common/ico_seach_over.png");
		$(".scloseBtn img").attr("src","img/common/btn_close.png");
		//$("#popup_searchs").empty();
		return false;
	});
	
	$("#searcheText").keydown(function(e){
		if(e.keyCode == "13"){
			//$(this).prev().children().focus();
			//$(".ico_search img").attr("src","./img/common/ico_seach_over.png");
		}
		if(e.keyCode == "40"){
			$(".menu_list li a").first().focus();
		}
	});
	

	$(".btn_back").click(function(){
		ncBackBtn();
		return false;
	});

	$(".btn_bye").click(function(){
		ncCloseBtn();
		return false;
	});



	////////////////////////// 검색 아이콘으로 이동했을때 ////////////////////////////
	$("#clickBtn").keydown(function(e){
		if(e.keyCode == "39"){
			$(".btn_back").focus();
			$(".ico_search img").attr("src","./img/common/ico_seach.png");
			$(".btn_back img").attr("src","./img/common/btn_back_over.png");
		}else if(e.keyCode == "37"){
			$(".searchInputTxt").hide();
			/*$(".modal_input_bg").show();*/
			$(this).parent().next().focus();
			$(".ico_search img").attr("src","./img/common/ico_seach.png");
		}else if(e.keyCode == "38"){
		}else if(e.keyCode == "40"){
			$(".ico_search img").attr("src","./img/common/ico_seach.png");
			$(".menu_list li:eq(0) a").focus();
		}
	});

	////////////////////////// back 아이콘으로 이동했을때 ////////////////////////////
	$(".btn_back").keydown(function(e){
		if(e.keyCode == "39"){
			$(".btn_back img").attr("src","./img/common/btn_back.png");
			$(".btn_bye img").attr("src","./img/common/btn_bye_over.png");
			$(".btn_bye").focus();
		}else if(e.keyCode == "37"){
			$(".ico_search").focus();
			$(".btn_back img").attr("src","./img/common/btn_back.png");
			$(".ico_search img").attr("src","./img/common/ico_seach_over.png");
		}else if(e.keyCode == "38"){
		}else if(e.keyCode == "40"){
			$(".menu_list li:eq(0) a").focus();
			$(".btn_back img").attr("src","./img/common/btn_back.png");
		}else if(e.keyCode == '13'){
			window.NetCastBack();
			//alert("zzzzzzzzzzzzzzzzzzzzz");
		}
	});
	
	////////////////////////// bye 아이콘으로 이동했을때 ////////////////////////////
	$(".btn_bye").keydown(function(e){
		if(e.keyCode == "39"){
			$(".btn_bye img").attr("src","./img/common/btn_bye.png");
			$(".menu_list li:eq(0) a").focus();
		}else if(e.keyCode == "37"){
			$(".btn_back img").attr("src","./img/common/btn_back_over.png");
			$(".btn_bye img").attr("src","./img/common/btn_bye.png");
			$(".btn_back").focus();
		}else if(e.keyCode == "38"){
		}else if(e.keyCode == "40"){
			$(".menu_list li:eq(0) a").focus();
			$(".btn_bye img").attr("src","./img/common/btn_bye.png");
		}else if(e.keyCode == '13'){
			window.NetCastExit();
			//alert("zzzzzzzzzzzzzzzzzzzzz");
		}
	});

	
	$(".menu_list li").keydown(function(e){
		if(e.keyCode == "39"){
			$("dl:eq("+(selectedOneDepth-1)+") dt:eq(0) a").focus();
			currentFocus = $("dl:eq("+(selectedOneDepth-1)+") dt:eq(0) a");
			if($("dl:eq("+(selectedOneDepth-1)+") dt:eq(0) a").children().attr("class") != undefined){
				twoDepthOverFunc($("dl:eq("+(selectedOneDepth-1)+") dt:eq(0)"));	
			}else{
				twoDepthOverFunc($("dl:eq("+(selectedOneDepth-1)+") dt:eq(0)"));
			}
		}
		else if(e.keyCode == "38"){
			if($(this).first().index() == 1){  // 최상단일때 위로 이동 못하게..
				$("#searcheText").focus();
				//$("#clickBtn").focus();
				//$("#clickBtn img").attr("src","./img/common/ico_seach_over.png");
				//$(".searchInputTxt").hide();
				depth_one();
			}
			$(this).prev().children("a").focus();
			currentFocus = $(this).prev().children("a");
		}else if(e.keyCode == "37"){
			if($(this).first().index() == 1){  // 최상단일때 위로 이동 못하게..
				$(".btn_bye").focus();
				$(".btn_bye img").attr("src","./img/common/btn_bye_over.png");
				depth_one();
			}
		}else if(e.keyCode == "40"){
			$(this).next().children("a").focus();
			currentFocus = $(this).next().children("a");
			oneDepthOut($(this));
			$(this).css("background-color","#ededed");
		}
		
	});



/*-------------------------- two Depth 키보드 누룰때 ----------------------------*/
	$(".contents_list dt").keydown(function(e){
		if(e.keyCode == "39"){
		}else if(e.keyCode == "38"){
			
			if($(this).next(".slide").css("display") != "none"){
				$(this).next(".slide").slideUp();	
			}
			
			if($(this).first().index() == 0){  // 최상단일때 위로 이동 못하게..
				//$("#searcheText").focus();
				$(".btn_bye img").attr("src","./img/common/btn_bye_over.png");
				$(".btn_bye").focus();
			}
			
			if($(this).prev().attr("class") == "slide"){   // 위(up) 버튼을 눌렀을때 객체가 ol.slide 이면
				//$(".slide li a").focus();		
				if($(this).prev(".slide").css("display") != "none"){ //.slide객체가 열려 있으면..
					$(this).prev().children("li").last().children("a").focus();
					currentFocus = $(this).prev().children("li").last().children("a");
					twoDepthOutFunc($(this));
					twoDepthOutFunc($(this).next());
				}else{ //.slide객체가 닫혀 있으면...						
					$(this).prev().prev().children("a").focus();	
					currentFocus = $(this).prev().prev().children("a");
					twoDepthOverFunc($(this).prev().prev());
					twoDepthOutFunc($(this));
				}
			}else{ // 위 버튼 눌렀을때 객체가 ol.slide가 아닐때
				$(this).prev().children("a").focus();	  
				currentFocus = $(this).prev().children("a");
				twoDepthOutFunc($(this));
				twoDepthOverFunc($(this).prev());
			}
			
		}else if(e.keyCode == "37"){//좌측(left)버튼을 눌렀을때 one Depth 메뉴로 이동
			$(".menu_list li:eq("+(selectedOneDepth-1)+") a").focus();
			currentFocus = $(".menu_list li:eq("+(selectedOneDepth-1)+") a");
			twoDepthOutFunc($(this)); //문제해결해야 할 곳.... 
		}else if(e.keyCode == "40"){
			var twoDepthListCount = $(this).parent().children().length;
			
			if($(this).last().index() == twoDepthListCount-1){ //하위메뉴가 없을때 이동하지 못하게...
				return;
			}
						
			if($(this).next().attr("class") == "slide"){ //아래(down)버튼을 누렀을때 다음객체가 ol.slide 메뉴이면..
				//$(".slide li a").focus();
				if($(this).next(".slide").css("display") != "none"){//ol.slide 객체가 열려 있으면 three Depth 메뉴로 이동  
					$(this).next().children("li:eq(0)").children("a").focus();
					currentFocus = $(this).next().children("li:eq(0)").children("a"); 
					twoDepthOutFunc($(this));
					twoDepthSelectFunc($(this));
					threeDepthOverFunc($(this).next().children("li:eq(0)"));
				}else{//ol.slide 객체가 열려 있지 않으면 two Depth 다음 메뉴로 이동 
					$(this).next().next().children("a").focus();	
					currentFocus = $(this).next().next().children("a");
					twoDepthOutFunc($(this));
					twoDepthOverFunc($(this).next().next());
				}
			}else{//ol.slide 객체가 아니면 다음 two Depth 메뉴로 이동
				$(this).next(".depth2").children().focus();	
				currentFocus = $(this).next(".depth2").children("a");
				twoDepthOutFunc($(this));
				twoDepthOverFunc($(this).next());
			}
			
		}
		
	});
	
/*-------------------------- three Depth 키보드 누룰때 ----------------------------*/
	$(".slide li").keydown(function(e){
		if(e.keyCode == "39"){
		}else if(e.keyCode == "38"){
			
			if($(this).prev().get(0) != undefined){   //위(up) 버튼을 눌렀을때 three Depth 메뉴가 있다면..
				$(this).prev().children("a").focus(); //three Depth 메뉴	이전 메뉴로 이동
				currentFocus = $(this).prev().children("a"); 
				threeDepthOutFunc($(this));
				threeDepthOverFunc($(this).prev());
			}else{//위(up) 버튼을 눌렀을때 three Depth 메뉴가 없다면
				$(this).parent().prev().children("a").focus(); //상위메뉴 이전으로 이동
				currentFocus = $(this).parent().prev().children("a"); 
				threeDepthOutFunc($(this));
				$(this).parent().slideUp();
				twoDepthOverFunc($(this).parent().prev(),1);
			}
		}else if(e.keyCode == "37"){
			$(".menu_list li:eq("+(selectedOneDepth-1)+") a").focus();
			currentFocus = $(".menu_list li:eq("+(selectedOneDepth-1)+") a");
		}else if(e.keyCode == "40"){
			if($(this).next().get(0) != undefined){  	//아래(down)을 버튼을 눌렀을때 three Depth 메뉴가 있을때..
				$(this).next().children("a").focus();	//다음 메뉴로 이동
				currentFocus = $(this).next().children("a"); 
				threeDepthOverFunc($(this).next());
				threeDepthOutFunc($(this));
				
			}else{ //three Depth 메뉴가 없을때
				$(this).parent().next().children("a").focus(); //상위 다음메뉴로 이동
				currentFocus = $(this).parent().next().children("a");
				threeDepthOutFunc($(this));
				twoDepthOutFunc($(this).parent().prev(),1);
				$(this).parent().slideUp();
				twoDepthOverFunc($(this).parent().next(),1);
			}
		}
	});	
});

////////////////////////////////// end $(function(){}); /////////////////////////////////	


////////////////////// two Depth Over, Select, Out /////////////////////////////
function twoDepthOverFunc(obj, existPlus){
	obj.css({"background-color":"#cf0652","color":"#fff"});
	obj.children().css({"background-position-y":"-26px","background-color":"#cf0652", "color":"#fff"});
	obj.children().children().css({"background-position-y":"-26px","background-color":"#cf0652", "color":"#fff"});
}

function twoDepthSelectFunc(obj,existPlus){
	//obj.css({"background-position-y":"-52px", "color":"#cf0652"});
	obj.children().children().css({"background-position-y":"-52px", "color":"#cf0652"});
}


function twoDepthClickFunc(obj,existPlus){
	obj.children().css({"background-color":"#fff","background-position-y":"-52px", "color":"#cf0652"});
	obj.css({"background-color":"#fff", "color":"#cf0652"})
}

function twoDepthClearFunc(){
	$(".contents_list dt a").children().css({"background-color":"#fff","background-position-y":"0px", "color":"#717171"});
	$(".contents_list dt a").css({"background-color":"#fff", "color":"#717171"})
}	

function twoDepthOutFunc(obj,existPlus){
	obj.css({"background-color":"#fff","color":"#717171"});
	obj.children().children().css({"background-position-y":"0px", "background-color":"#fff", "color":"#717171"});
	obj.children().css({"background-position-y":"0px","background-color":"#fff", "color":"#717171"});	
}
	

//////////////////// three Depth Over, Select, Out ////////////////////////////
function threeDepthOverFunc(obj){
	obj.children().css({"background-position-y":"-60px","background-color":"#cf0652", "color":"#fff"});
	obj.css({"background-color":"#cf0652","background-position-y":"-60px", "color":"#fff"});
}

function threeDepthOutFunc(obj){
	obj.css({"background-color":"#fff","background-position-y":"0px", "color":"#717171"});
	obj.children().css({"background-position-y":"0px","background-color":"#fff", "color":"#717171"});
}

function threeDepthSelectFunc(obj){
	obj.css({"background-color":"#fff","background-position-y":"-60px", "color":"#717171"});
	obj.children().css({"background-position-y":"-60px","background-color":"#fff", "color":"#717171"});
}
	
//popup 떳을때 focus
function setPopupFocusList(){
	$(".closeBtn").focus();
	$(".closeBtn img").attr("src","./img/common/btn_close_over.png");
	//document.getElementById("popupIframe").focus();
	//$(".frame").focus();
	//$(".closeBtn img").attr("src","./img/common/btn_close_over.png");
}

function depth_one(){  //one Depth를 초기화 하는 함수
	$(".menu_list li a").removeClass("select").css("background-position-y","0px").css("background-color","");
	$(".menu_list li a").children().css({"background-position-y":"0px", "color":"#717171"});
}

function depth_two(){  //two Depth를 초기화 하는 함수
	//$(".contents_list dt a").removeClass("select");
	//$(".contents_list dt a").children().css({"background-position-y":"0px", "color":"#717171"})
	$(".slide").slideUp();
}

function popupClose(){ //팝업창을 닫는 함수	
	//$(".popup").hide();
	//$(".popup_search").hide();
	if(currentFocus){  //저장해 놓은 currentFocus에 focus()를 줌.
		currentFocus.focus();	
	}
	
}

function menuInit(){
	$(".menu_list li a").removeClass(".over");
}

function twoDepthInit(){
	$(".contents_list").hide();
}

function initmenu(){
	$(".menu_list li a").css({"background-position-y":"0px", "background-color":"#ededed"});
	$(".menu_list li a span").css({"color":"#717171", "background-position-y":"0px"});
}

function plus(){
	//$(".depth2 a").css("background-color", "transparent");
	//$(".depth2 a span").css({"background-position-y":"0px", "color":"#62615d"});
}

function ncBackBtn(){
	// back버튼을 눌렀을때...
}

function ncCloseBtn(){
	// close버튼을 눌렀을떄....
}



//언어관련부분 (Search 글자 변경 및 maxlength 조정 2014-01-16 김하나 추가
function ChangeMaxLength() {
	var langcode = $("html").attr("lang");
	var Strings = "Search";
//	var maxlength = 25; 1byte 언어일 때 25가 적당함 적용해야될지 말아야 할지?
	var maxlength = 14;
	switch(langcode){
		case 'en' : Strings = "Search"; break;
		case 'ko' : Strings = "검색어"; maxlength = 14; break;
		case 'sq' : Strings = "Kërko"; break; 
		case 'ar' : Strings = "البحث"; break;
		case 'bs' : Strings = "Търсене"; break;
		case 'zh-cn' : Strings = "搜索"; maxlength = 14; break;
		case 'cs' : Strings = "Vyhledávání"; break;
		case 'da' : Strings = "Søg"; break;
		case 'nl' : Strings = "Zoeken"; break;
		case 'et' : Strings = "Otsing"; break;
		case 'fi' : Strings = "Haku"; break;
		case 'fr' : Strings = "Rechercher"; break; 
		case 'de' : Strings = "Suchen"; break;
		case 'el' : Strings = "Αναζήτηση"; break;
		case 'he' : Strings = "חיפוש"; break;
		case 'hu' : Strings = "Keresés"; break; 
		case 'id' : Strings = "Cari"; break;
		case 'it' : Strings = "Cerca"; break;
		case 'ja' : Strings = "検索"; maxlength = 14; break;
		case 'kk' : Strings = "Іздеу"; break;
		case 'ku' : Strings = "گەڕان"; break;
		case 'lv' : Strings = "Meklēt"; break;
		case 'lt' : Strings = "Paieška"; break;
		case 'mk' : Strings = "Пребарување"; break;
		case 'ms' : Strings = "Cari"; break;
		case 'zh-tw' : Strings = "搜尋"; maxlength = 14; break;
		case 'no' : Strings = "Søk"; break;
		case 'fa' : Strings = "جستجو"; break;
		case 'pl' : Strings = "Szukaj"; break;
		case 'pt' : Strings = "Pesquisar"; break;
		case 'ro' : Strings = "Căutare"; break;
		case 'ru' : Strings = "Поиск"; break;
		case 'sr' : Strings = "Pretraga"; break;
		case 'hr' : Strings = "Pretraživanje"; break;
		case 'sk' : Strings = "Vyhľadávať"; break;
		case 'sl' : Strings = "Išči"; break;
		case 'es' : Strings = "Buscar"; break;
		case 'sv' : Strings = "Sök"; break;
		case 'th' : Strings = "ค้นหา"; break;
		case 'tr' : Strings = "Arama"; break;
		case 'uk' : Strings = "Пошук"; break;
		case 'uz' : Strings = "Izlash"; break;
		case 'vi' : Strings = "Tìm kiếm"; break;
		case 'zh-hk' : Strings = "搜尋"; maxlength = 14; break;
		default : Strings = "Search"; break;
	}
	window.searchStrings = Strings;
	$("#searcheText").val(Strings);
	$("#searcheText").attr("maxlength", maxlength);

	$("#searcheText").focusout(function(){
		if($(this).val() == "" || $(this).val() == Strings){
			$("#searcheText").val(Strings);
		}
	});

	$("#searcheText").focusin(function(e){
		if($(this).val() == "" || $(this).val() == Strings){
			$(this).val("");
		}
	});

	$(".scloseBtn").click(function(){  // 검색창 닫기
		$("#searcheText").removeAttr("readonly");
		$("#searcheText").val(Strings);
	});
	SearchStringModify(langcode);
}

//특수문자 방지  2014-01-16 김하나 추가
function Keycode(e){
	var code = (window.event) ? event.keyCode : e.which; //IE : FF - Chrome both
	if (code > 32 && code < 48) nAllow(e);
	if (code > 57 && code < 65) nAllow(e);
	if (code > 90 && code < 97) nAllow(e);
	if (code > 122 && code < 127) nAllow(e);
}
function nAllow(e){
	if(navigator.appName!="Netscape"){ //for not returning keycode value
		event.returnValue = false;  //IE ,  - Chrome both
	}else{
		e.preventDefault(); //FF ,  - Chrome both
	}        
}

//팝업창에서 화살표 위방향을 눌렀을 때 닫기 버튼으로  2014-01-16 김하나 추가
$("#iframeWrapper").keydown(function(e){
	if(e.keyCode == "38"){
		$(".iframediv").scrollTop()
		if($(".iframediv").scrollTop() == 0){

			$(".closeBtn").focus();
			$(".closeBtn img").attr("src","img/common/btn_close_over.png");
		}
		$("#iframeDiv").scrollTop
	}
});

$(".closeBtn").keydown(function(e){
	if(e.keyCode == "40"){
		$(".closeBtn img").attr("src","img/common/btn_close.png");
		$("#iframeDiv a").focus();
	}
});

//2014-01-23 김하나 추가 검색어, 검새결과개수 다국어 번역 부분
function SearchStringModify(langcode){
	if(langcode === 'en'){
		$(".ser_nav1:first-child").text("Search");
		$(".ser_nav1:last-child").text("Number of results");
		Strings = "Search";
	}

	else if(langcode === 'ko'){
		$(".ser_nav1:first-child").text("검색어");
		$(".ser_nav1:last-child").text("검색 항목 개수");
		Strings = "검색어";
	}
	
	else if(langcode === 'sq'){
		$(".ser_nav1:first-child").text("Kërko");
		$(".ser_nav1:last-child").text("Numri i rezultateve");
		Strings = "Kërko";
	}

	else if(langcode === 'ar'){
		$(".ser_nav1:first-child").text("البحث");
		$(".ser_nav1:last-child").text("عدد النتائج");
		Strings = "البحث";
	}

	else if(langcode === 'bs'){
		$(".ser_nav1:first-child").text("Pretraživanje");
		$(".ser_nav1:last-child").text("Broj rezultata");
		Strings = "Pretraživanje";
	}

	else if(langcode === 'bg'){
		$(".ser_nav1:first-child").text("Търсене");
		$(".ser_nav1:last-child").text("Брой резултати");
		Strings = "Търсене";
	}
	else if(langcode === 'zh-cn'){
		$(".ser_nav1:first-child").text("搜索");
		$(".ser_nav1:last-child").text("结果数量");
		Strings = "搜索";
	}
	else if(langcode === 'cs'){
		$(".ser_nav1:first-child").text("Vyhledávání");
		$(".ser_nav1:last-child").text("Počet výsledků");
		Strings = "Vyhledávání";
	}
	else if(langcode === 'da'){
		$(".ser_nav1:first-child").text("Søg");
		$(".ser_nav1:last-child").text("Antal resultater");
		Strings = "Søg";
	}
	else if(langcode === 'nl'){
		$(".ser_nav1:first-child").text("Zoeken");
		$(".ser_nav1:last-child").text("Aantal resultaten");
		Strings = "Zoeken";
	}
	else if(langcode === 'et'){
		$(".ser_nav1:first-child").text("Otsing");
		$(".ser_nav1:last-child").text("Otsingute arv");
		Strings = "Otsing";
	}
	else if(langcode === 'fi'){
		$(".ser_nav1:first-child").text("Haku");
		$(".ser_nav1:last-child").text("Tulosten lukumäärä");
		Strings = "Haku";
	}
	else if(langcode === 'fr'){
		$(".ser_nav1:first-child").text("Rechercher");
		$(".ser_nav1:last-child").text("Nombre de résultats");
		Strings = "Rechercher";
	}
	else if(langcode === 'de'){
		$(".ser_nav1:first-child").text("Suchen");
		$(".ser_nav1:last-child").text("Anzahl der Ergebnisse");
		Strings = "Suchen";
	}
	else if(langcode === 'el'){
		$(".ser_nav1:first-child").text("Αναζήτηση");
		$(".ser_nav1:last-child").text("Αριθμός αποτελεσμάτων");
		Strings = "Αναζήτηση";
	}
	else if(langcode === 'he'){
		$(".ser_nav1:first-child").text("חיפוש");
		$(".ser_nav1:last-child").text("מספר התוצאות");
		Strings = "חיפוש";
	}
	else if(langcode === 'hu'){
		$(".ser_nav1:first-child").text("Keresés");
		$(".ser_nav1:last-child").text("A találatok száma");
		Strings = "Keresés";
	}
	else if(langcode === 'id'){
		$(".ser_nav1:first-child").text("Cari");
		$(".ser_nav1:last-child").text("Jumlah hasil");
		Strings = "Cari";
	}
	else if(langcode === 'it'){
		$(".ser_nav1:first-child").text("Cerca");
		$(".ser_nav1:last-child").text("Numero di risultati");
		Strings = "Cerca";
	}
	else if(langcode === 'ja'){
		$(".ser_nav1:first-child").text("検索");
		$(".ser_nav1:last-child").text("検索結果数");
		Strings = "検索";
	}
	else if(langcode === 'kk'){
		$(".ser_nav1:first-child").text("Іздеу");
		$(".ser_nav1:last-child").text("Нәтижелер саны");
		Strings = "Іздеу";
	}
	else if(langcode === 'ku'){
		$(".ser_nav1:first-child").text("گەڕان");
		$(".ser_nav1:last-child").text("ژمارەی دەرەنجامەکان");
		Strings = "گەڕان";
	}
	else if(langcode === 'lv'){
		$(".ser_nav1:first-child").text("Meklēt");
		$(".ser_nav1:last-child").text("Rezultātu skaits");
		Strings = "Meklēt";
	}
	else if(langcode === 'lt'){
		$(".ser_nav1:first-child").text("Paieška");
		$(".ser_nav1:last-child").text("Rezultatų skaičius");
		Strings = "Paieška";
	}
	else if(langcode === 'mk'){
		$(".ser_nav1:first-child").text("Пребарување");
		$(".ser_nav1:last-child").text("Број на резултати");
		Strings = "Пребарување";
	}
	else if(langcode === 'ms'){
		$(".ser_nav1:first-child").text("Cari");
		$(".ser_nav1:last-child").text("Bilangan hasil");
		Strings = "Cari";
	}
	else if(langcode === 'zh-tw'){
		$(".ser_nav1:first-child").text("搜尋");
		$(".ser_nav1:last-child").text("結果筆數");
		Strings = "搜尋";
	}
	else if(langcode === 'no'){
		$(".ser_nav1:first-child").text("Søk");
		$(".ser_nav1:last-child").text("Antall resultater");
		Strings = "Søk";
	}
	else if(langcode === 'fa'){
		$(".ser_nav1:first-child").text("جستجو");
		$(".ser_nav1:last-child").text("تعداد نتایج");
		Strings = "جستجو";
	}
	else if(langcode === 'pl'){
		$(".ser_nav1:first-child").text("Szukaj");
		$(".ser_nav1:last-child").text("Liczba wyników");
		Strings = "Szukaj";
	}
	else if(langcode === 'pt'){
		$(".ser_nav1:first-child").text("Pesquisar");
		$(".ser_nav1:last-child").text("Número de resultados");
		Strings = "Pesquisar";
	}
	else if(langcode === 'ro'){
		$(".ser_nav1:first-child").text("Căutare");
		$(".ser_nav1:last-child").text("Număr rezultate");
		Strings = "Căutare";
	}
	else if(langcode === 'ru'){
		$(".ser_nav1:first-child").text("Поиск");
		$(".ser_nav1:last-child").text("Количество результатов");
		Strings = "Поиск";
	}
	else if(langcode === 'sr'){
		$(".ser_nav1:first-child").text("Pretraga");
		$(".ser_nav1:last-child").text("Broj rezultata");
		Strings = "Pretraga";
	}
	else if(langcode === 'hr'){
		$(".ser_nav1:first-child").text("Pretraživanje");
		$(".ser_nav1:last-child").text("Broj rezultata");
		Strings = "Pretraživanje";
	}
	else if(langcode === 'sk'){
		$(".ser_nav1:first-child").text("Vyhľadávať");
		$(".ser_nav1:last-child").text("Počet výsledkov");
		Strings = "Vyhľadávať";
	}
	else if(langcode === 'sl'){
		$(".ser_nav1:first-child").text("Išči");
		$(".ser_nav1:last-child").text("Število rezultatov");
		Strings = "Išči";
	}
	else if(langcode === 'es'){
		$(".ser_nav1:first-child").text("Buscar");
		$(".ser_nav1:last-child").text("Número de resultados");
		Strings = "Buscar";
	}
	else if(langcode === 'sv'){
		$(".ser_nav1:first-child").text("Sök");
		$(".ser_nav1:last-child").text("Antal resultat");
		Strings = "Sök";
	}
	else if(langcode === 'th'){
		$(".ser_nav1:first-child").text("ค้นหา");
		$(".ser_nav1:last-child").text("จำนวนของผลลัพธ์");
		Strings = "ค้นหา";
	}
	else if(langcode === 'tr'){
		$(".ser_nav1:first-child").text("Arama");
		$(".ser_nav1:last-child").text("Sonuç sayısı");
		Strings = "Arama";
	}
	else if(langcode === 'uk'){
		$(".ser_nav1:first-child").text("Пошук");
		$(".ser_nav1:last-child").text("Кількість результатів");
		Strings = "Пошук";
	}
	else if(langcode === 'uz'){
		$(".ser_nav1:first-child").text("Izlash");
		$(".ser_nav1:last-child").text("Natijalar soni");
		Strings = "Izlash";
	}
	else if(langcode === 'vi'){
		$(".ser_nav1:first-child").text("Tìm kiếm");
		$(".ser_nav1:last-child").text("Số lượng kết quả");
		Strings = "Tìm kiếm";
	}
	else if(langcode === 'zh-hk'){
			$(".ser_nav1:first-child").text("搜尋");
			$(".ser_nav1:last-child").text("結果數目");
		Strings = "搜尋";
	}
	else{
		$(".ser_nav1:first-child").text("Search");
		$(".ser_nav1:last-child").text("Number of results");
		Strings = "Search";
	}
}