var searchFocus;
$(function(){
	$("#popup_searchs li:eq(0)").addClass("select").css({"background-color":"#da1961"});
	$("#popup_searchs li:eq(0)").children().css({"color":"#fff", "background-position-y":"-76px"});
	
//	$("body").keydown(function(e){
//		if(e.keyCode == "38"){
//			if(window.pageYOffset == 0){
//				//$("popupIframe",parent.document).find(".closBtn").focus();
//				$(".closeBtn").focus();
//				$(".closeBtn img").attr("src","img/common/btn_close_over.png");
//			}
//		}
//	});
});

function init(){
	$("li")	.css({"background-color":"#686868"});
	$(".title1").css({"color":"#fff"});
	$(".title2").css({"color":"#c8c8c8", "background-position-y":"-16px"})
}

function setPopupIframe(){
	//parent.$("#popupIframe").contents().find("body").focus();
	$("#popupIframe",parent.document).contents().find("body").focus();
}
