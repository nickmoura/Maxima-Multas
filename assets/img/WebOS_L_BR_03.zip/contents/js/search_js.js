window.htmlStr = "";
var searchString;
var tempPath;
window.selecteSearchList;
var langcode = $("html").attr("lang");
var Strings = "Search";

function getSearch(){
	$("#searcheText").attr("readonly", "readonly");

	var str = $("#searcheText").val();
	searchString = str;
	
	if(searchString == ""){
		$("#searcheText").focus();
		return;
	}

	$("#searcheText").val(window.searchStrings);
	
	if(searchString == window.searchStrings){
		$("#searcheText").focus();
		return;
	}

	$(".popup_search").show();
	$(".modal_search_bg").show();
	$(".ser_nav2").text(searchString);	
	
	
	var i = 0;
		
	$.each(window.param, function( key, val) {
			
			if (val.body.match(new RegExp(searchString, 'i')) != null){
				var strBody = new Array(val.body.match(new RegExp(searchString, 'i')));
				var tempTitle = val.title;
				var sTitle = tempTitle.replace(new RegExp(searchString, 'i'),"<span class='highlight'>"+strBody+"</span>");
				var tempSummary = val.summary;
				var sSummary = tempSummary;

				if(tempSummary.match(new RegExp(searchString, 'i')) != null){
					var strSummary = new Array(tempSummary.match(new RegExp(searchString, 'i')));
					sSummary = tempSummary.replace(new RegExp(searchString, 'i'),"<span class='highlight'>"+strSummary+"</span>");
				}

				window.htmlStr += '<li><a href="'+val.link+'" navi="'+val.navi+'"><p class="title1">' + sTitle + '</p>';
				window.htmlStr += '<p class="title2">' + sSummary + '</p></a></li>';
				i++;
			}			
	});

	if(i == 0){
		$(".scloseBtn").focus();
		$(".scloseBtn img").attr("src","img/common/btn_close_over.png");
//		window.htmlStr += '<li><a href=\"#\"><p class="title1">A</p>';
//		window.htmlStr += '<p class="title2">B</p></a></li>';
	}
	
	$(".ser_nav_no").text(i);
	ajaxView();	
}


function iframeSetFocus(){
	setFocusList();
}

function ajaxView(){
	$("#searchIframe").html("<ul id='popup_searchs'>"+window.htmlStr+"</ul>");
	setFocusList();
	window.htmlStr = "";
}

function getIframeContent(id){
	var ifrm = document.getElementById(id);
	return ifrm.contentWindow || ifrm.contentDocument;
}


function setFocusList(){
	$("#popup_searchs").children("li:eq(0)").children("a").focus();
	$("#popup_searchs").children("li:eq(0)").addClass("select").css({"background-color":"#cf0652"});
	$("#popup_searchs").children("li:eq(0)").children().css({"color":"#fff", "background-position-y":"-72px"});
}

function setPopupFocusList(){
	$("#popupIframe").contents().find("body").focus();
	$("#popupIframe").attr("src","");
}

function init(){
	$("#popup_searchs li").css({"background-color":"#686868"});
	$(".title1").css({"color":"#fff"});
	$(".title2").css({"color":"#c8c8c8", "background-position-y":"-12px"})
}


$(function(){
	$("#clickBtn").click(function() {
		getSearch();
		$(this).children().attr("src","img/common/ico_seach.png");
		return false;
	});
	
	$("#searcheText").keydown(function(e){
		if(e.keyCode == "13"){
			if($("#searcheText").val() != "" && $("#searcheText").val() != Strings){
				getSearch();
				return false;
			}
		}
	});

	$(".scloseBtn").keydown(function(e){
		if(e.keyCode == "40"){
			//$(".menu_list li:eq(0) a").focus();
			//setTimeout(iframeSetFocus,500);
			if($("#popup_searchs li").length < 0){
				$(".scloseBtn img").attr("src","img/common/btn_close.png");
				setFocusList();	
			}
		}
	});

	$(".closeBtn").keydown(function(e){
		if(e.keyCode == "40"){
			//$(".menu_list li:eq(0) a").focus();
			//setTimeout(iframeSetFocus,500);
			$(".closeBtn img").attr("src","img/common/btn_close.png");
			$iframe = $("#popupIframe").focus();
		}
	});

		
	////////////////////////// 검색리스트 /////////////////////////////////

	$("body").on("keydown","#popup_searchs li",function(e){
		if(e.keyCode == "38"){
			if($(this).index() == 0){
				$(".scloseBtn").focus();
				$(".scloseBtn img").attr("src","img/common/btn_close_over.png");
			};
			$(this).prev().children("a").focus();
			$(this).removeClass("select").css({"background-color":"#686868"});
			$(this).children().css({"color":"#fff", "background-position-y":"0px"});

			$(this).prev().addClass("select").css({"background-color":"#cf0652"});
			$(this).prev().children().css({"color":"#fff", "background-position-y":"-76px"});
		}else if(e.keyCode == "40"){

			var searchListCount = $("#popup_searchs li").length;
			
			if($(this).last().index() == searchListCount-1){ //하위메뉴가 없을때 이동하지 못하게...
				return;
			}			
			
			$(this).next().children("a").focus();
			
			$(this).removeClass("select").css({"background-color":"#686868"});
			$(this).children().css({"color":"#fff", "background-position-y":"0px"});

			$(this).next().addClass("select").css({"background-color":"#cf0652"});
			$(this).next().children().css({"color":"#fff", "background-position-y":"-76px"});
			
		}
	});

	$("body").on("mouseover","#popup_searchs li",function(e){
		$(this).children("a").focus();
		$(this).addClass("select").css({"background-color":"#da1961"});
		$(this).children().css({"color":"#fff", "background-position-y":"-76px"});
		$(".scloseBtn img").attr("src","img/common/btn_close.png");
	});

	$("body").on("mouseleave","#popup_searchs li", function(e){
		$(this).removeClass("select").css({"background-color":"#686868"});
		$(this).children().css({"color":"#fff", "background-position-y":"0px"});
	});

	$("body").on("click","#popup_searchs li a",function(){
		
		var tempPath = $(this).attr("navi");	
		path = tempPath.split(">@");
		$("#oneDepth_navi").html(path[0]);
		$("#twoDepth_navi").html(path[1]);
		$("#thrDepth_navi").hide();
		if(path[2]){
			$("#thrDepth_navi").html(path[2]);
			$("#thrDepth_navi").hide();
		}
		var searchURL = $(this).attr("href");
		window.selectedSearchList = $(this);
		window.searchInputCheck = true;
		$(".popup").show();
		$(".modal_bg").show();
		$("#popupIframe").attr("src",searchURL);
		$(".closeBtn").focus();
		$(".closeBtn img").attr("src","./img/common/btn_close_over.png");
		
		return false;
	});	
});
